import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-picker-popover',
  templateUrl: './date-picker-popover.component.html',
  styleUrls: ['./date-picker-popover.component.scss'],
})
export class DatePickerPopoverComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}

export interface Reflection{
    id:string,
    date: string,
    description: string, 
    good: string,
    bad: string 
}


export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBtpxdcPw6cr3mPcAoVtn-DAETEqT3Ozoc",
    authDomain: "task-app-3f397.firebaseapp.com",
    projectId: "task-app-3f397",
    storageBucket: "task-app-3f397.appspot.com",
    messagingSenderId: "986129283555",
    appId: "1:986129283555:web:0ba8be791fb9da00e408d6"
  }
};
